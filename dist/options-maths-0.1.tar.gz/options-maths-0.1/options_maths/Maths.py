class OMath(object):
    def __init__(self):
        print("hello world")